#ANARCHY!!!!1

###MVP:
	1. Map generation
	2. Turn-based combat
	3. Projectiles and collision damage
	4. Menu
	5. Character model(s)

###Objects
	1. Players
		{
			health: *int*,
			ammo:   *int*, 
			move:   *int*
		}
	2. Map : 
		[{
			height: *int*,
			type:   *String*
		}]

###Todo Stuff: 
	1. Generate a map.
